package com.atguigu.common.valid;

public interface AddGroup {
}
